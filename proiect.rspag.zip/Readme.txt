This package was created by the Pack & Go wizard in RobotStudio. It contains
all files necessary to open the station "proiect.rsstn" on a different computer.
The following settings were used:
- Libraries will be copied into the package
- Don't pack ABB standard libraries
- Include backups of all robot systems in the package
